﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace MyPlugins
{
    public class SyncProductItemPriceUpdate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service
            ITracingService tracingService =
            (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            // The InputParameters collection contains all the data passed in the message request.  
            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {
                

                // Obtain the organization service reference which you will need for  
                // web service calls.  
                IOrganizationServiceFactory serviceFactory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                //IOrganizationService adminservice = serviceFactory.CreateOrganizationService(new Guid(""));


                Entity productitementity = (Entity)context.InputParameters["Target"];           

                Guid recordid = (Guid)context.PrimaryEntityId;

                Guid subprodid = Guid.NewGuid();

                decimal dbitemprice = 0;

                string msg = string.Empty;

                try
                {

                    // Plug-in business logic goes here.  
                   // msg += "Try Begins!";

                    // in below leadimage has been added in plugin registration tool

                    // get PreImage from Context

                    if (context.PreEntityImages.Contains("ProductItemImage") && context.PreEntityImages["ProductItemImage"] is Entity)
                    {

                        Entity preMessageImage = (Entity)context.PreEntityImages["ProductItemImage"];

                        //Guid presubprodid = (Guid)preMessageImage.Attributes["new_productid"];
                        Guid presubprodid = ((EntityReference)preMessageImage.Attributes["new_productid"]).Id;
                        subprodid = presubprodid;
                        msg += presubprodid;
                    }


                    // get PostImage from Context
                    if (context.PostEntityImages.Contains("ProductItemImage") &&
                           context.PostEntityImages["ProductItemImage"] is Entity)

                    {

                        Entity postMessageImage = (Entity)context.PostEntityImages["ProductItemImage"];


                        // Guid postsubprodid = (Guid)postMessageImage.Attributes["new_productid"];     
                        Guid postsubprodid = ((EntityReference)postMessageImage.Attributes["new_productid"]).Id;
                        subprodid = postsubprodid;
                        msg += postsubprodid;
                    }

                    //msg += " Record Id: " + recordid;
                    //msg += " Query Expression Begins!";
                    QueryExpression query = new QueryExpression("new_productitem");
                    //msg += " ColumnSet Begins!";
                    query.ColumnSet = new ColumnSet(new string[] { "new_productid", "new_productitemid", "new_itemprice" });
                    //msg += " Criteria Condition Begins!";
                    query.Criteria.AddCondition("new_productid", ConditionOperator.Equal, subprodid);
                    //msg += " Entity Collection Begins!";
                    EntityCollection entityCollection = service.RetrieveMultiple(query);
                    //msg += " EC If Condition Begins!";
                    if (entityCollection.Entities.Count > 0)
                    {
                        foreach (Entity proditemsprice in entityCollection.Entities)
                        {
                            dbitemprice += Convert.ToDecimal(proditemsprice["new_itemprice"]);
                        }
                        //msg += dbitemprice;
                    }
                    //msg += " EC If Condition Ends!";

                    //msg += " Entity Product Initialized begins!";
                    Entity product = new Entity("product");
                    product["productid"] = subprodid;
                    product["new_totalprice"] = dbitemprice;
                    //msg += " Product Id: " + subprodid;
                    //msg += " Total Price: " + dbitemprice;
                    service.Update(product);
                    //msg += " Service Updated!";
                    //msg += "Out of If!";
                    tracingService.Trace(msg);
                }



                catch (FaultException<OrganizationServiceFault> ex)
                {
                    //msg += " in catch";
                    throw new InvalidPluginExecutionException("An error occurred in FollowUpPlugin. " + msg, ex);
                }

                catch (Exception ex)
                {
                    tracingService.Trace("FollowUpPlugin: {0}", ex.ToString());
                    throw;
                }
            }
        }
    }
}
