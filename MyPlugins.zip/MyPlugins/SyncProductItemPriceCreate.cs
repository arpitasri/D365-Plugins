﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace SyncItemPricePlugin
{
    public class SyncProductItemPriceCreate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service
            ITracingService tracingService =
            (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            // The InputParameters collection contains all the data passed in the message request.  
            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {
                // Obtain the target entity from the input parameters.  
                Entity productitem = (Entity)context.InputParameters["Target"];

                // Obtain the organization service reference which you will need for  
                // web service calls.  
                IOrganizationServiceFactory serviceFactory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                //IOrganizationService adminservice = serviceFactory.CreateOrganizationService(new Guid(""));

                string parentprodid = string.Empty;
                decimal prodtotprice = 0;
                // string subprodid = string.Empty;
                string itemname = string.Empty;
                string itemid = string.Empty;
                decimal itemprice = 0;

                decimal dbitemprice = 0;
                decimal totprice = 0;

                string msg = string.Empty;

                try
                {
                    // Plug-in business logic goes here.  
                    //parentprodid = Convert.ToString(entity.Attributes["productnumber"]);
                    //prodtotprice = Convert.ToDecimal(entity.Attributes["new_totalprice"]);
                    //subprodid = Convert.ToString(entity.Attributes["new_productid"]);
                    //itemname = Convert.ToString(entity.Attributes["new_name"]);
                    //itemid = Convert.ToString(entity.Attributes["new_itemid"]);
                    //itemprice = Convert.ToDecimal(entity.Attributes["new_itemprice"]);

                    msg += "Its all started from here!";
                    //if ((productitem.Attributes.Contains("new_productid")))
                    //{
                        msg += " I am  Under IF statement";

                        EntityReference subprodid = (EntityReference)productitem.Attributes["new_productid"];
                        //var subprodidLookupName = subprodid.Name;
                        var subprodidLookupId = subprodid.Id;

                        //msg += "Product Name: " + subprodidLookupName + " ";
                        msg += "Product Id: " + subprodidLookupId;
                        msg += " subprodid from form";

                        itemprice = Convert.ToDecimal(productitem.Attributes["new_itemprice"]);

                        msg += " itemprice from form";

                        QueryExpression query = new QueryExpression("new_productitem");
                        msg += " base line query from table";

                        //query.ColumnSet = new ColumnSet(new string[] { "new_productid", "new_name", "new_itemid", "new_itemprice" });
                        query.ColumnSet = new ColumnSet(new string[] { "new_productitemid" , "new_itemprice" });
                        //msg += " columnsets";
                      
                        query.Criteria.AddCondition("new_productid", ConditionOperator.Equal, subprodidLookupId);
                        msg += " checked conditions";
                        EntityCollection entityCollection = service.RetrieveMultiple(query);
                        if (entityCollection.Entities.Count > 0)
                         {
                            msg += " checked counts";
                            foreach (Entity proditemsprice in entityCollection.Entities)
                            {
                                msg += " checked item price from db";
                                dbitemprice += Convert.ToDecimal(proditemsprice["new_itemprice"]);
                            }
                            
                         }

                        msg += " retrieving records";

                        //totprice = itemprice + dbitemprice;

                        msg += totprice;
                        msg += " added tot price";

                        Entity product = new Entity("product");
                        product["productid"] = subprodidLookupId;

                        product["new_totalprice"] = dbitemprice;

                        service.Update(product);

                        msg += "Updated!";
                    //}
                    msg += " out of main if";
                    tracingService.Trace(msg);
                }



                catch (FaultException<OrganizationServiceFault> ex)
                {
                    msg += " in catch";
                    throw new InvalidPluginExecutionException("An error occurred in FollowUpPlugin. " + msg, ex);
                }

                catch (Exception ex)
                {
                    tracingService.Trace("FollowUpPlugin: {0}", ex.ToString());
                    throw;
                }
            }
        }
    }
}
