﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.Xml;

namespace MyPlugins
{
    public class QualifyLeadPlugin : IPlugin
    {
        IOrganizationService service;
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service
            ITracingService tracingService =
            (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            //if (context.MessageName != "QualifyLead")
            //    return;

            //The InputParameters collection contains all the data passed in the message request.
            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {
                // Obtain the target entity from the input parameters.  
                Entity entity = (Entity)context.InputParameters["Target"];

                // Obtain the organization service reference which you will need for  
                // web service calls.  
                IOrganizationServiceFactory serviceFactory =
                   (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = serviceFactory.CreateOrganizationService(context.UserId);

                //Get the qualified Lead
                EntityReference leadid = (EntityReference)context.InputParameters["LeadId"];
                //ColumnSet attributes2 = new ColumnSet(new string[] { "new_contact", "new_existingcustomer" });
                //Entity lead = service.Retrieve(leadid.LogicalName, leadid.Id, attributes2);

                string msg = string.Empty;

                try
                {
                    // Plug-in business logic goes here.  
                    msg += "Its all started from here!";
                    //var qualifyRequest = new QualifyLeadRequest();
                    //qualifyRequest.Parameters = context.InputParameters;
                    //qualifyRequest.CreateOpportunity = false;

                    //if (lead.Contains("new_contact") && lead.Contains("new_existingcustomer") && lead.Attributes["new_contact"] != null && lead.Attributes["new_existingcustomer"] != null)
                    //{

                    var qualifyrequest = new QualifyLeadRequest();
                    qualifyrequest.Parameters = context.InputParameters;
                    qualifyrequest.CreateOpportunity = false;
                    qualifyrequest.CreateAccount = false;
                    qualifyrequest.CreateContact = true;

                    //msg += "Updating Parameters";

                    //    context.InputParameters["CreateOpportunity"] = false;


                    //msg += "Create Opp set to false!";

                    //    context.InputParameters["CreateAccount"] = false;

                    //msg += "Create Account set to false!";

                    //    context.InputParameters["CreateContact"] = true;

                    //msg += "Create Contact set to true!";

                    //    context.InputParameters["SuppressDuplicateDetection"] = true;

                    //msg += "Suppress DuplicateDetection set to true!";

                    //}

                    //else if ((!lead.Contains("new_contact")) && lead.Contains("new_existingcustomer") && lead.Attributes["new_existingcustomer"] != null)
                    //{
                    //    context.InputParameters["CreateOpportunity"] = false;
                    //    context.InputParameters["CreateAccount"] = false;
                    //    context.InputParameters["CreateContact"] = true;
                    //    context.InputParameters["SuppressDuplicateDetection"] = true;
                    //}

                    //else
                    //{
                    //    context.InputParameters["SuppressDuplicateDetection"] = true;
                    //    context.InputParameters["CreateOpportunity"] = false;
                    //}

                    msg += " out";
                    tracingService.Trace(msg);

                }

                catch (FaultException<OrganizationServiceFault> ex)
                {
                    msg += " in catch";
                    throw new InvalidPluginExecutionException("An error occurred in FollowUpPlugin. " + msg, ex);
                }

                catch (Exception ex)
                {
                    tracingService.Trace("FollowUpPlugin: {0}", ex.ToString());
                    throw;
                }
            }

            else
            {
                IOrganizationServiceFactory serviceFactory =
                   (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = serviceFactory.CreateOrganizationService(context.UserId);

                //Get the qualified Lead
                EntityReference leadid = (EntityReference)context.InputParameters["LeadId"];
                //ColumnSet attributes2 = new ColumnSet(new string[] { "new_contact", "new_existingcustomer" });
                //Entity lead = service.Retrieve(leadid.LogicalName, leadid.Id, attributes2);

                string msg = string.Empty;

                try
                {
                    // Plug-in business logic goes here.  
                    msg += "Its all started from here!";
                    //var qualifyRequest = new QualifyLeadRequest();
                    //qualifyRequest.Parameters = context.InputParameters;
                    //qualifyRequest.CreateOpportunity = false;

                    //if (lead.Contains("new_contact") && lead.Contains("new_existingcustomer") && lead.Attributes["new_contact"] != null && lead.Attributes["new_existingcustomer"] != null)
                    //{

                    var qualifyrequest = new QualifyLeadRequest();
                    qualifyrequest.Parameters = context.InputParameters;
                    qualifyrequest.CreateOpportunity = false;
                    qualifyrequest.CreateAccount = true;
                    qualifyrequest.CreateContact = false;
                    context.InputParameters["SuppressDuplicateDetection"] = true;

                    //msg += "Updating Parameters";

                    //    context.InputParameters["CreateOpportunity"] = false;


                    //msg += "Create Opp set to false!";

                    //    context.InputParameters["CreateAccount"] = false;

                    //msg += "Create Account set to false!";

                    //    context.InputParameters["CreateContact"] = true;

                    //msg += "Create Contact set to true!";

                    //    context.InputParameters["SuppressDuplicateDetection"] = true;

                    //msg += "Suppress DuplicateDetection set to true!";

                    //}

                    //else if ((!lead.Contains("new_contact")) && lead.Contains("new_existingcustomer") && lead.Attributes["new_existingcustomer"] != null)
                    //{
                    //    context.InputParameters["CreateOpportunity"] = false;
                    //    context.InputParameters["CreateAccount"] = false;
                    //    context.InputParameters["CreateContact"] = true;
                    //    context.InputParameters["SuppressDuplicateDetection"] = true;
                    //}

                    //else
                    //{
                    //    context.InputParameters["SuppressDuplicateDetection"] = true;
                    //    context.InputParameters["CreateOpportunity"] = false;
                    //}

                    msg += " out";
                    tracingService.Trace(msg);

                }

                catch (FaultException<OrganizationServiceFault> ex)
                {
                    msg += " in catch";
                    throw new InvalidPluginExecutionException("An error occurred in FollowUpPlugin. " + msg, ex);
                }

                catch (Exception ex)
                {
                    tracingService.Trace("FollowUpPlugin: {0}", ex.ToString());
                    throw;
                }
            }

        }

        private static string GetErrorCode(XmlNode errorInfo)
        {
            XmlNode code = errorInfo.SelectSingleNode("//code");

            if (code != null)
                return code.InnerText;
            else
                return "";
        }

    }
}
